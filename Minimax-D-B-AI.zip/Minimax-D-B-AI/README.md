# Minimax-D-B-AI
A team repository for a mini-maxing AI that plays dots and boxes
